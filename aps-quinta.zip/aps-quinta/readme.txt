Utilizado jdk 8.
Executar na ordem:
Executar no projeto aps-bancos : BancoDados1.java, BancoDados2.java e BancoDados3.java
Executar no projeto aps-servidor-controlador: ServidorControlador.java
Executar no projeto aps-cliente: TelaInicial.java